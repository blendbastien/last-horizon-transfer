# Last Horizon Transfer 1.1.0

Exporte tout le contenu d'une partie Foundry (v13) dans un fichier `.json`, puis l'importe dans une autre partie.
Pensé pour passer d'une partie Forge à une autre, même quand les deux n'utilisent pas le même système
(par exemple Custom System Builder → Manhwa Sheet).

## Utilisation
1. Activer le module dans les deux parties.
2. Partie source : Paramètres → « Exporter cette partie » (ou le bouton en bas de l'onglet Paramètres). Cocher les types voulus, télécharger le `.json`.
3. Partie de destination : « Importer dans cette partie », choisir le fichier, vérifier l'écran de confirmation (types, correspondance des types, conflits, permissions, réglages), importer.
4. Recharger la page (F5).

## Ce qui passe
Acteurs (avec leurs objets et effets), objets, journaux (pages comprises), scènes (tokens, tuiles, murs, lumières, notes, sons…), tables aléatoires, macros, playlists, paquets de cartes, messages de chat (décochés par défaut), dossiers (hiérarchie conservée), réglages de monde des modules (données du catalogue, des scénarios, etc.).

## Ce qui ne passe pas
- Les fichiers eux-mêmes (images, musiques) : seuls les chemins sont copiés. Sur Forge la bibliothèque d'assets est commune à toutes tes parties, donc rien à faire.
- Les utilisateurs et leurs permissions par joueur (réinitialisées par défaut ; permission « par défaut » conservée).
- Les compendiums, les combats, les réglages client.

## Entre deux systèmes différents
Les données `system` des acteurs et objets ne sont pas compatibles d'un système à l'autre. Elles sont conservées intactes dans
`flags.last-horizon-transfer.source` (système d'origine, type d'origine, données) : rien n'est perdu. Les types « template » de CSB
(`_template`, `subTemplate`, …) ne sont pas créés dans la destination (ils servent seulement à classer les objets).

## Conversion CSB (fiche-manhwa) → Manhwa Sheet
Quand la source est Custom System Builder et la destination Manhwa Sheet, l'écran d'import propose la conversion (cochée par défaut),
qui lit la configuration réelle de la partie de destination :
- Personnage : niveau, rang, éveil (`classe`), monde → origine, constellation → sponsor, stats et monnaies (table de correspondance
  préremplie et modifiable à l'écran), identité (≈ 55 champs), titre équipé, cadrage du portrait.
- Objets : catégorie (d'après le template CSB puis le `type` de l'objet), rang, rareté, quantité, valeur, niveau, élément, coût, portée,
  exécution, monde, constructeur, places, description, lore, cadrage, équipable ; le reste des propriétés va dans `extra`.
- Les valeurs qui n'existent pas dans la config de destination (un rang F absent, une rareté inconnue…) sont listées dans le rapport
  final : ajoute-les dans la config Manhwa Sheet puis réimporte en mode « Écraser ».
Pour que les objets soient bien classés, l'acteur `_template` de la fiche doit être dans le fichier (coche « Acteurs » à l'export) ;
les identifiants des templates de la fiche « Fiche Manhwa » sont aussi connus en repli.

## Recréer la fiche CSB dans la configuration Manhwa Sheet
À l'import (case cochée par défaut si l'acteur `_template` est dans le fichier), ou via Paramètres → « Config Manhwa Sheet depuis la fiche CSB »
(fichier Transfert ou export JSON de l'acteur `_template` ; télécharger la config ou l'appliquer). Généré depuis le template :
stats (clés, libellés, minimum), monnaies de l'en-tête, rangs (menu `rang`), mondes → origines (menu `monde`), éveils (valeurs de `classe`),
sections d'identité (sous-onglets, champs, types court / riche / liste), et les listes de raretés, éléments, coûts, portées, exécutions
d'après les valeurs réellement utilisées par les objets du fichier. L'arbre des catégories, le mode de jeu, les jauges et l'XP sont conservés.
L'ancienne configuration est sauvegardée dans les sauvegardes de Manhwa Sheet. Avec cette config, la conversion est 1 pour 1.

## Conflits d'identifiants
Par défaut les identifiants sont conservés (les tokens des scènes retrouvent leurs acteurs). Si un document existe déjà avec le même
identifiant : Ignorer (défaut), Écraser, ou Dupliquer (nouvel identifiant ; les références des scènes sont remappées).

## API
`game.modules.get("last-horizon-transfer").api.export()` / `.import()`.
